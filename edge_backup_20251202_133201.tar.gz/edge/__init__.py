"""
Edge Layer - TFM Supervisor de Cargas
"""
__version__ = '1.0.0'
